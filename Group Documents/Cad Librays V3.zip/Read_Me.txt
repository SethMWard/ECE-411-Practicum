Update 3
Date: 11/4/2014
Time:12:54 AM

notes
SW1801x
1) reduced size of SW1801x vibration seansores
2) added discription of SW1801x Vibration sensors
3) Added Name to SW1801x Vibration sensors

New Components
RBP.lbr
1) Added RBP-440+ Band Pass filter 410MHz-470MHz
SMT.lbr
1) Added SMT-1640-S-2-R pizo speaker
Switch.lbr
1) Added 275-0601 SPST toggle switch
SYM.lbr
1) Added NCV1117ST50TSG voltage regulator PAK:SOT223