T-11 V_5 Update
Date 11/5/14
Time: 2:43 AM

.SCH
	1) Remved T-11 Info marker.

.LBR
	1) Added group name.
	2) Added Product name.
	3) Added Version number.
	4) Added 3.6mm mounting holes