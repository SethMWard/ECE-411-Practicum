LED-Brake-out-board update notes
Date 11/5/14
Time: 1:04 AM

LED Header
	1) Changed Pin Location to match T-11 board.

LED
	1) Changed package to LED_LD260.

Notes
	1) Added corresponding GPIO pin names to nets.
	2) Added PCB board design.