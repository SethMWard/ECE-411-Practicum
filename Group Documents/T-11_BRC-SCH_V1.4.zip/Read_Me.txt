V_4 Update
Date:11/5/14
Time:12:25 AM

.sch update notes
	1)Changed LED header Pin connections for better board layout.
	2)Changed buzzer to SMT-1640
	3)Changed buzzer to an active low device
.brd
	1) Added a board layout.
.lbr
	1) Added Part Name to lt5538