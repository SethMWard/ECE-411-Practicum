T-11 LED_Brakout_v4 Update
Date 11/8/14
Time: 13:05

.SCH
	none
.LBR
	1) Changed resister pakage to 0805.
	2) Moved mounting holes to 3.81mm from edge of board