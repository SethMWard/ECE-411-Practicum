T-11 LED Brakeout V_3 Update
Date 11/5/14
Time: 10:41 AM

.SCH
	1) Added a frame to schematic.
.LBR
	1) Added a product Name to the board.
	2) Increased board size.
	3) Added mounting holes.