T-11 Brakeout board Update
Date 11/9/14
Time: 22:44

.SCH
	none
.LBR
	1) Increaced power trace width.